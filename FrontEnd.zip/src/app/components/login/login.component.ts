import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit, ViewChild, inject } from '@angular/core';
import { FormsModule, NgForm, NgModel } from '@angular/forms';
import { AuthService } from '../../services/auth.service';
import { ToastContainerDirective, ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import { RecaptchaModule } from 'ng-recaptcha';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule, RecaptchaModule, CommonModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css',
})
export class LoginComponent implements OnInit {
  captchaResolved = false;
  captchaResponse: string | null = null;

  constructor(
    private authService: AuthService,
    private toastrService: ToastrService
  ) {}

  router = inject(Router);

  @ViewChild(ToastContainerDirective, { static: true })
  toastContainer!: ToastContainerDirective;

  ngOnInit() {
    this.toastrService.overlayContainer = this.toastContainer;
  }

  loginObj: any = {
    userName: '',
    password: '',
  };

  resolved(captchaResponse: string | null) {  // Updated to accept string | null
    this.captchaResponse = captchaResponse;
    this.captchaResolved = !!captchaResponse;
  }

  onSubmit(form: NgForm) {
    if (this.captchaResolved && form.valid) {
      this.authService.loginUser(this.loginObj).subscribe(
        (res: any) => {
          if (res.success) {
            localStorage.setItem('loggedUser', res.username);
            localStorage.setItem('loggedUserRole', res.role);
            localStorage.setItem('loggedUserToken', res.token);
            this.toastrService.success('Logged in successfully!!', 'Success');
            
            if (res.role === 'ADMIN') {
              this.router.navigateByUrl('/admin');
            } else if (res.role === 'USER') {
              this.router.navigateByUrl('/user');
            }
          } else {
            this.toastrService.error(
              'There was an error while logging in. Please try again!!',
              'Error'
            );
            form.reset();
          }
        },
        (error: HttpErrorResponse) => {
          if (error.error?.text) {
            this.toastrService.error(error.error.text, 'Error');
          } else {
            this.toastrService.error(
              'An error occurred: ' + error.message,
              'Error'
            );
          }
        }
      );
    }
  }
}