﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace MentalHealthServiceAPI.Migrations
{
    /// <inheritdoc />
    public partial class initialMentalHealthDB : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
